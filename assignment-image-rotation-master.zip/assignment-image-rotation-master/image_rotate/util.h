#include "pixel.h"

#ifndef LAB_BMP_ROTATE_UTIL_H
#define LAB_BMP_ROTATE_UTIL_H
    void pixel_copy(struct pixel* p1, struct pixel* p2);
#endif //LAB_BMP_ROTATE_UTIL_H
